
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sustancia`
--
-- Creación: 31-10-2025 a las 15:39:22
--

CREATE TABLE `sustancia` (
  `ID_Sustancia` int(4) NOT NULL,
  `Nombre_Sustancia` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `Frecuencia` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACIONES PARA LA TABLA `sustancia`:
--   `ID_Sustancia`
--       `paciente_sustancia` -> `ID_Sustancia`
--
