
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `enfermedades_crónicas`
--
-- Creación: 22-10-2025 a las 17:49:57
--

CREATE TABLE `enfermedades_crónicas` (
  `ID_Enfermedad` int(4) NOT NULL COMMENT 'Identificador de la Enfermedad',
  `Nombre_Enfermedad` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL COMMENT 'Nombre de la Enfermedad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACIONES PARA LA TABLA `enfermedades_crónicas`:
--

--
-- Volcado de datos para la tabla `enfermedades_crónicas`
--

INSERT INTO `enfermedades_crónicas` (`ID_Enfermedad`, `Nombre_Enfermedad`) VALUES
(1, 'Ninguna'),
(2, 'Diabetes tipo 1'),
(3, 'Diabetes tipo 2'),
(4, 'Hipertensión arterial'),
(5, 'Dislipidemia'),
(6, 'Enfermedad coronaria'),
(7, 'Insuficiencia cardíaca'),
(8, 'Arritmias'),
(9, 'Accidente cerebrovascular'),
(10, 'EPOC'),
(11, 'Asma'),
(12, 'Apnea del sueño'),
(13, 'Insuficiencia renal crónica'),
(14, 'Enfermedad hepática crónica'),
(15, 'Hipotiroidismo'),
(16, 'Hipertiroidismo'),
(17, 'Osteoporosis'),
(18, 'Artritis reumatoide'),
(19, 'Enfermedad autoinmune'),
(20, 'Cáncer'),
(21, 'Epilepsia'),
(22, 'Parkinson'),
(23, 'Trastorno psiquiátrico'),
(24, 'Obesidad'),
(25, 'Tromboembolismo venoso'),
(26, 'Otro');
