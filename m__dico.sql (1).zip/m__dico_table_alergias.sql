
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alergias`
--
-- Creación: 31-10-2025 a las 16:19:11
-- Última actualización: 15-11-2025 a las 18:35:46
--

CREATE TABLE `alergias` (
  `ID_Alergia` int(4) NOT NULL COMMENT 'Identificador de la Alergia',
  `Alergia` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL COMMENT 'Nombre de la Alergia'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabla con lista de Alergias';

--
-- RELACIONES PARA LA TABLA `alergias`:
--

--
-- Volcado de datos para la tabla `alergias`
--

INSERT INTO `alergias` (`ID_Alergia`, `Alergia`) VALUES
(1, 'Ninguna'),
(2, 'Penicilina'),
(3, 'Amoxicilina'),
(4, 'Cefalosporinas'),
(5, 'Macrólidos'),
(6, 'Tetraciclinas'),
(7, 'Aminoglucósidos'),
(8, 'Quinolonas'),
(9, 'Sulfonamidas'),
(10, 'Anestésicos locales'),
(11, 'Anestésicos generale'),
(12, 'AINE'),
(13, 'Ibuprofeno'),
(14, 'Naproxeno'),
(15, 'Paracetamol'),
(16, 'Látex'),
(17, 'Mariscos'),
(18, 'Crustáceos'),
(19, 'Pescado'),
(20, 'Frutos secos'),
(21, 'Huevo'),
(22, 'Leche'),
(23, 'Polen'),
(24, 'Ácaros del polvo'),
(25, 'Moho'),
(26, 'Picaduras de insecto'),
(27, 'Perfumes'),
(28, 'Metales'),
(29, 'Otro');
