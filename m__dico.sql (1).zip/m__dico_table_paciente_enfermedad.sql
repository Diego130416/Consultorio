
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente_enfermedad`
--
-- Creación: 15-11-2025 a las 20:02:37
--

CREATE TABLE `paciente_enfermedad` (
  `ID_PE` int(4) NOT NULL,
  `ID_Enfermedad` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACIONES PARA LA TABLA `paciente_enfermedad`:
--   `ID_Enfermedad`
--       `enfermedades_crónicas` -> `ID_Enfermedad`
--   `ID_PE`
--       `paciente` -> `ID_Paciente`
--
