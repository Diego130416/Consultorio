
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicación_actual`
--
-- Creación: 07-11-2025 a las 16:39:20
--

CREATE TABLE `medicación_actual` (
  `ID_Medicación` int(4) NOT NULL COMMENT 'Identificador de Medicamento',
  `Nombre_Medicamento` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL COMMENT 'Nombre del Medicamento'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACIONES PARA LA TABLA `medicación_actual`:
--

--
-- Volcado de datos para la tabla `medicación_actual`
--

INSERT INTO `medicación_actual` (`ID_Medicación`, `Nombre_Medicamento`) VALUES
(23, 'Alprazolam'),
(18, 'Amoxicilina'),
(29, 'Antidepresivos'),
(30, 'Antipsicóticos'),
(4, 'Aspirina'),
(11, 'Atorvastatina'),
(19, 'Cefalexina'),
(21, 'Codeína'),
(22, 'Diazepam'),
(8, 'Enalapril'),
(25, 'Fluoxetina'),
(3, 'Ibuprofeno'),
(7, 'Insulina'),
(15, 'Levotiroxina'),
(9, 'Lisinopril'),
(10, 'Losartán'),
(6, 'Metformina'),
(17, 'Metotrexato'),
(5, 'Naproxeno'),
(1, 'Ninguna'),
(13, 'Omeprazol'),
(31, 'Otro'),
(14, 'Pantoprazol'),
(2, 'Paracetamol'),
(16, 'Prednisona'),
(27, 'Rivaroxabán'),
(28, 'Salbutamol'),
(24, 'Sertralina'),
(12, 'Simvastatina'),
(20, 'Tramadol'),
(26, 'Warfarina');
