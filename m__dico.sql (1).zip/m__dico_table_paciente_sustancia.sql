
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente_sustancia`
--
-- Creación: 15-11-2025 a las 20:11:24
--

CREATE TABLE `paciente_sustancia` (
  `ID_PS` int(4) NOT NULL,
  `ID_Sustancia` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACIONES PARA LA TABLA `paciente_sustancia`:
--   `ID_PS`
--       `paciente` -> `ID_Paciente`
--
