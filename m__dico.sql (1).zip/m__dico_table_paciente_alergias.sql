
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente_alergias`
--
-- Creación: 15-11-2025 a las 19:53:31
--

CREATE TABLE `paciente_alergias` (
  `ID_PA` int(4) NOT NULL,
  `ID_Alergia` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACIONES PARA LA TABLA `paciente_alergias`:
--   `ID_Alergia`
--       `alergias` -> `ID_Alergia`
--   `ID_PA`
--       `paciente` -> `ID_Paciente`
--
