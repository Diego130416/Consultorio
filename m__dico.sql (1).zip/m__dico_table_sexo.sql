
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sexo`
--
-- Creación: 04-11-2025 a las 16:47:41
--

CREATE TABLE `sexo` (
  `Sexo` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT 'Masculino'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACIONES PARA LA TABLA `sexo`:
--

--
-- Volcado de datos para la tabla `sexo`
--

INSERT INTO `sexo` (`Sexo`) VALUES
('Femenino'),
('Masculino'),
('Otro');
