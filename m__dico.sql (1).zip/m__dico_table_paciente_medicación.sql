
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente_medicación`
--
-- Creación: 15-11-2025 a las 20:11:00
--

CREATE TABLE `paciente_medicación` (
  `ID_PM` int(4) NOT NULL,
  `ID_medicación` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACIONES PARA LA TABLA `paciente_medicación`:
--   `ID_medicación`
--       `medicación_actual` -> `ID_Medicación`
--   `ID_PM`
--       `paciente` -> `ID_Paciente`
--
