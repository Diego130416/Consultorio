
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--
-- Creación: 15-11-2025 a las 20:31:26
-- Última actualización: 15-11-2025 a las 21:27:26
--

CREATE TABLE `paciente` (
  `ID_Paciente` int(4) NOT NULL COMMENT 'Identificador del Paciente.',
  `Nombre` varchar(50) NOT NULL COMMENT 'Nombre del Paciente',
  `Apellido_Paterno` varchar(50) NOT NULL,
  `Apellido_Materno` varchar(50) NOT NULL,
  `Edad` tinyint(2) NOT NULL COMMENT 'Edad del Paciente',
  `Sexo` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `FechaDeNacimiento` date NOT NULL DEFAULT current_timestamp() COMMENT 'Año, mes y día de nacimiento.',
  `Teléfono` char(20) NOT NULL,
  `RFC` varchar(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `Antecedentes_Familiares` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `ID_Cirugía` int(4) NOT NULL,
  `Motivo_Consulta` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `Síntoma` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONES PARA LA TABLA `paciente`:
--   `Sexo`
--       `sexo` -> `Sexo`
--
