
--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alergias`
--
ALTER TABLE `alergias`
  ADD PRIMARY KEY (`ID_Alergia`);

--
-- Indices de la tabla `enfermedades_crónicas`
--
ALTER TABLE `enfermedades_crónicas`
  ADD PRIMARY KEY (`ID_Enfermedad`);

--
-- Indices de la tabla `medicación_actual`
--
ALTER TABLE `medicación_actual`
  ADD PRIMARY KEY (`ID_Medicación`),
  ADD KEY `Nombre_Medicamento` (`Nombre_Medicamento`);

--
-- Indices de la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD PRIMARY KEY (`ID_Paciente`),
  ADD UNIQUE KEY `ID_Paciente` (`ID_Paciente`),
  ADD KEY `Sexo` (`Sexo`);

--
-- Indices de la tabla `paciente_alergias`
--
ALTER TABLE `paciente_alergias`
  ADD PRIMARY KEY (`ID_PA`),
  ADD KEY `ID_Alergia` (`ID_Alergia`),
  ADD KEY `ID_PA` (`ID_PA`);

--
-- Indices de la tabla `paciente_enfermedad`
--
ALTER TABLE `paciente_enfermedad`
  ADD PRIMARY KEY (`ID_PE`),
  ADD KEY `ID_Enfermedad` (`ID_Enfermedad`);

--
-- Indices de la tabla `paciente_medicación`
--
ALTER TABLE `paciente_medicación`
  ADD PRIMARY KEY (`ID_PM`),
  ADD KEY `ID_medicación` (`ID_medicación`);

--
-- Indices de la tabla `paciente_sustancia`
--
ALTER TABLE `paciente_sustancia`
  ADD PRIMARY KEY (`ID_PS`),
  ADD KEY `ID_Sustancia` (`ID_Sustancia`);

--
-- Indices de la tabla `receta`
--
ALTER TABLE `receta`
  ADD PRIMARY KEY (`ID_Receta`);

--
-- Indices de la tabla `sexo`
--
ALTER TABLE `sexo`
  ADD PRIMARY KEY (`Sexo`),
  ADD UNIQUE KEY `Nombre` (`Sexo`);

--
-- Indices de la tabla `sustancia`
--
ALTER TABLE `sustancia`
  ADD PRIMARY KEY (`ID_Sustancia`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alergias`
--
ALTER TABLE `alergias`
  MODIFY `ID_Alergia` int(4) NOT NULL AUTO_INCREMENT COMMENT 'Identificador de la Alergia', AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT de la tabla `enfermedades_crónicas`
--
ALTER TABLE `enfermedades_crónicas`
  MODIFY `ID_Enfermedad` int(4) NOT NULL AUTO_INCREMENT COMMENT 'Identificador de la Enfermedad', AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `medicación_actual`
--
ALTER TABLE `medicación_actual`
  MODIFY `ID_Medicación` int(4) NOT NULL AUTO_INCREMENT COMMENT 'Identificador de Medicamento', AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `paciente`
--
ALTER TABLE `paciente`
  MODIFY `ID_Paciente` int(4) NOT NULL AUTO_INCREMENT COMMENT 'Identificador del Paciente.', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `paciente_alergias`
--
ALTER TABLE `paciente_alergias`
  MODIFY `ID_PA` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `paciente_enfermedad`
--
ALTER TABLE `paciente_enfermedad`
  MODIFY `ID_PE` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `paciente_medicación`
--
ALTER TABLE `paciente_medicación`
  MODIFY `ID_PM` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `paciente_sustancia`
--
ALTER TABLE `paciente_sustancia`
  MODIFY `ID_PS` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `receta`
--
ALTER TABLE `receta`
  MODIFY `ID_Receta` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `sustancia`
--
ALTER TABLE `sustancia`
  MODIFY `ID_Sustancia` int(4) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD CONSTRAINT `paciente_ibfk_1` FOREIGN KEY (`Sexo`) REFERENCES `sexo` (`Sexo`);

--
-- Filtros para la tabla `paciente_alergias`
--
ALTER TABLE `paciente_alergias`
  ADD CONSTRAINT `paciente_alergias_ibfk_1` FOREIGN KEY (`ID_Alergia`) REFERENCES `alergias` (`ID_Alergia`),
  ADD CONSTRAINT `paciente_alergias_ibfk_2` FOREIGN KEY (`ID_PA`) REFERENCES `paciente` (`ID_Paciente`);

--
-- Filtros para la tabla `paciente_enfermedad`
--
ALTER TABLE `paciente_enfermedad`
  ADD CONSTRAINT `paciente_enfermedad_ibfk_2` FOREIGN KEY (`ID_Enfermedad`) REFERENCES `enfermedades_crónicas` (`ID_Enfermedad`),
  ADD CONSTRAINT `paciente_enfermedad_ibfk_3` FOREIGN KEY (`ID_PE`) REFERENCES `paciente` (`ID_Paciente`);

--
-- Filtros para la tabla `paciente_medicación`
--
ALTER TABLE `paciente_medicación`
  ADD CONSTRAINT `paciente_medicación_ibfk_2` FOREIGN KEY (`ID_medicación`) REFERENCES `medicación_actual` (`ID_Medicación`),
  ADD CONSTRAINT `paciente_medicación_ibfk_3` FOREIGN KEY (`ID_PM`) REFERENCES `paciente` (`ID_Paciente`);

--
-- Filtros para la tabla `paciente_sustancia`
--
ALTER TABLE `paciente_sustancia`
  ADD CONSTRAINT `paciente_sustancia_ibfk_1` FOREIGN KEY (`ID_PS`) REFERENCES `paciente` (`ID_Paciente`);

--
-- Filtros para la tabla `sustancia`
--
ALTER TABLE `sustancia`
  ADD CONSTRAINT `sustancia_ibfk_1` FOREIGN KEY (`ID_Sustancia`) REFERENCES `paciente_sustancia` (`ID_Sustancia`);
